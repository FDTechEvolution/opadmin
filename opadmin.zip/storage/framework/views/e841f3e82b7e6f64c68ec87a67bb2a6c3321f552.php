<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="shortcut icon" href="<?php echo e(asset('images/favicon_1.ico')); ?>">

        <title>OP Admin - OrderPang Admin WebApp.</title>

        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/icons.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    </head>


    <body class="fixed-left">
        <div id="app">
            <div id="wrapper">
                <topbar-component></topbar-component>
                <sidebar-component></sidebar-component>
            </div>
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">
                        <router-view></router-view>
                    </div>
                </div>
            </div>
        </div>
    </body>

</html>

<script src="<?php echo e(mix('/js/app.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\git\opadmin\resources\views/app.blade.php ENDPATH**/ ?>