<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="shortcut icon" href="<?php echo e(asset('images/favicon_1.ico')); ?>">

        <title>OP Admin - OrderPang Admin WebApp.</title>

        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/icons.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">

    </head>
    <body>
        <div id="app">
            <login-component></login-component>
        </div>
    </body>
</html>


<script src="<?php echo e(mix('/js/app.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\git\opadmin\resources\views/login.blade.php ENDPATH**/ ?>